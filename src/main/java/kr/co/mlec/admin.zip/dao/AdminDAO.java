package kr.co.mlec.admin.dao;

import java.util.List;
import java.util.Map;

import kr.co.mlec.member.vo.MemberVO;

public interface AdminDAO {
	List<MemberVO> selectCustomer(int pageNo);
	int selectCustomerCount();
	 List<Map<String,Object>> selectFile(int pageNo);
	int selectFileCount();
	List<Map<String,Object>> selectFileByKeyword(Map<String, String> map);
	int selectFileByKeywordCount(Map<String,String> map);
}
